from django.contrib import admin
from app1.models import EmpModel

from app1.models import StudentModel

# Register your models here.
admin.site.register(StudentModel)
admin.site.register(EmpModel)

      
